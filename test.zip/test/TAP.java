package test;

28. Tạo ứng dụng với JTable
java

Copier
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class JTableExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("JTable Example");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        String[] columnNames = {"Tên", "Tuổi", "Điểm"};
        Object[][] data = {
            {"Nguyễn Văn A", 20, 8.5},
            {"Lê Thị B", 21, 9.0},
            {"Trần Văn C", 22, 7.5},
            {"Phạm Thị D", 20, 8.0},
            {"Hoàng Văn E", 19, 8.8},
        };

        JTable table = new JTable(new DefaultTableModel(data, columnNames));
        JScrollPane scrollPane = new JScrollPane(table);

        frame.add(scrollPane);
        frame.setVisible(true);
    }
}
29. Tạo ứng dụng với CardLayout
java

Copier
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CardLayoutExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("CardLayout Example");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        CardLayout cardLayout = new CardLayout();
        JPanel cardPanel = new JPanel(cardLayout);

        JPanel card1 = new JPanel();
        card1.add(new JLabel("Page 1"));

        JPanel card2 = new JPanel();
        JButton button = new JButton("Click");
        card2.add(button);

        cardPanel.add(card1, "Card1");
        cardPanel.add(card2, "Card2");

        JButton switchButton = new JButton("Switch");
        switchButton.addActionListener(e -> cardLayout.next(cardPanel));

        frame.add(cardPanel, BorderLayout.CENTER);
        frame.add(switchButton, BorderLayout.SOUTH);
        frame.setVisible(true);
    }
}
30. Tạo ứng dụng với JToolBar
java

Copier
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JToolBarExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("JToolBar Example");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JToolBar toolBar = new JToolBar();
        JButton newButton = new JButton("New");
        JButton saveButton = new JButton("Save");
        JButton openButton = new JButton("Open");

        toolBar.add(newButton);
        toolBar.add(saveButton);
        toolBar.add(openButton);

        newButton.addActionListener(e -> JOptionPane.showMessageDialog(frame, "New clicked"));
        saveButton.addActionListener(e -> JOptionPane.showMessageDialog(frame, "Save clicked"));
        openButton.addActionListener(e -> JOptionPane.showMessageDialog(frame, "Open clicked"));

        frame.add(toolBar, BorderLayout.NORTH);
        frame.setVisible(true);
    }
}
31. Tạo ứng dụng với JSplitPane
java

Copier
import javax.swing.*;

public class JSplitPaneExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("JSplitPane Example");
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JList<String> list = new JList<>(new String[]{"Item 1", "Item 2", "Item 3", "Item 4"});
        JTextArea textArea = new JTextArea();

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JScrollPane(list), new JScrollPane(textArea));
        splitPane.setDividerLocation(200);

        frame.add(splitPane);
        frame.setVisible(true);
    }
}
32. Tạo ứng dụng với JTextArea
java

Copier
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JTextAreaExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("JTextArea Example");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTextArea textArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(textArea);

        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(e -> textArea.setText(""));

        frame.add(scrollPane, BorderLayout.CENTER);
        frame.add(clearButton, BorderLayout.SOUTH);
        frame.setVisible(true);
    }
}
33. Thiết kế form với GridBagLayout
java

Copier
import javax.swing.*;
import java.awt.*;

public class GridBagLayoutExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("GridBagLayout Example");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField(15);
        JLabel ageLabel = new JLabel("Age:");
        JSpinner ageSpinner = new JSpinner(new SpinnerNumberModel(18, 0, 100, 1));
        JButton submitButton = new JButton("Submit");

        gbc.gridx = 0; gbc.gridy = 0;
        frame.add(nameLabel, gbc);
        gbc.gridx = 1;
        frame.add(nameField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        frame.add(ageLabel, gbc);
        gbc.gridx = 1;
        frame.add(ageSpinner, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        frame.add(submitButton, gbc);

        frame.setVisible(true);
    }
}
34. Tạo ứng dụng với JSpinner
java

Copier
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class JSpinnerExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("JSpinner Example");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JSpinner spinner = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
        JLabel label = new JLabel("Value: 1");

        spinner.addChangeListener(e -> label.setText("Value: " + spinner.getValue()));

        frame.add(spinner, BorderLayout.CENTER);
        frame.add(label, BorderLayout.SOUTH);
        frame.setVisible(true);
    }
}
35. Kết hợp nhiều Layout Manager
java

Copier
import javax.swing.*;
import java.awt.*;

public class MultiLayoutExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Multi-Layout Example");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setLayout(new BorderLayout());

        JPanel gridPanel = new JPanel(new GridLayout(3, 3));
        for (int i = 1; i <= 9; i++) {
            gridPanel.add(new JButton("Button " + i));
        }

        JButton resetButton = new JButton("Reset");

        frame.add(gridPanel, BorderLayout.CENTER);
        frame.add(resetButton, BorderLayout.SOUTH);
        frame.setVisible(true);
    }
}