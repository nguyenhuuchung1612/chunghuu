package test;

import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class Test1 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Random Background Color");
        JPanel panel = new JPanel();
        JButton stopButton = new JButton("Stop");
        Timer timer = new Timer(1000, e -> panel.setBackground(new Color(new Random().nextInt(256), new Random().nextInt(256), new Random().nextInt(256))));

        stopButton.addActionListener(e -> {
            timer.stop();
            stopButton.setEnabled(false);
        });

        frame.add(panel, BorderLayout.CENTER);
        frame.add(stopButton, BorderLayout.SOUTH);
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        timer.start();
    }
}